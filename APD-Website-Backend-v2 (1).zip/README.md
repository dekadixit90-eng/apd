# APD website + backend (v2)

Assam Property Dealer, Guwahati. Residential flats for sale only.

**Status: code-complete first version, NOT yet run end to end.** It was syntax-checked only (no database, no internet in the build environment). Follow "First run" and the test checklist below before trusting it.

## What is in this project
| Area | Where | State |
|---|---|---|
| Public site (navy/gold, existing design kept) | `public/index.html`, `public/live.js` | Loads live listings, localities, filters, compare, EMI, WhatsApp, enquiry + visit forms |
| Locality directory (58 localities, 5 zones, search, A-Z, live counts) | `server/prisma/seed.js`, `/api/localities` | Counts come from the database, never hard-coded |
| Admin dashboard (`/admin`) | `public/admin.html`, `public/admin.js` | Properties, localities, categories, enquiries (CRM), visits, staff, sales & brokerage, users, settings, reports |
| API + roles + audit log | `server/src/*.js` | Roles: SUPER_ADMIN, ADMIN, ACCOUNTS, EXECUTIVE |
| Database | `server/prisma/schema.prisma` | PostgreSQL via Prisma (works with Supabase or the bundled Docker database) |
| Photo/video storage | `server/src/admin.js` | Cloudflare R2 if configured, otherwise server disk |
| HTTPS + deploy | `docker-compose.yml`, `Caddyfile` | Caddy gets a free HTTPS certificate once your domain points at the server |

## First run (on your computer)
1. Install Docker Desktop.
2. Copy `.env.example` to `.env`. Set `POSTGRES_PASSWORD` to a long random password.
3. `docker compose build` then `docker compose up -d`
4. Create your admin login: `docker compose exec app node src/create-admin.js yourusername` (SUPER_ADMIN, password 14+ characters).
5. Open http://localhost:3000 (site) and http://localhost:3000/admin (dashboard).
6. In the dashboard: add a staff member, then add one property with photos and set it to **Available**. Refresh the public site: it must appear, and the locality count must change.

The first start creates all tables and fills the locality list, categories and office details (only if those tables are empty).

## Connections you must set up
1. **Hosting server (VPS).** Any Linux VPS with Docker. Copy this folder to it, create `.env`, run `docker compose --profile prod up -d`.
2. **Domain.** Buy one yourself (e.g. assampropertydealer.in or .com, if free). Add an `A` record (and `www`) pointing to the VPS IP. Put the domain in `.env` as `DOMAIN=`. Caddy then issues HTTPS automatically.
3. **Database.** Default: the bundled Postgres container (nothing to connect; back it up). Optional: Supabase. Paste its Postgres connection string into `.env` as `DATABASE_URL` and remove the `db` service. Supabase free projects pause after a week of inactivity; use a paid plan for a live business site.
4. **Photo/video storage.** Default: server disk (volume `apd_uploads`, back it up). Optional: Cloudflare R2. Create a bucket, make it public (custom domain recommended), create an API token with Object Read & Write, then fill the five `R2_*` values in `.env`.
5. **First admin account.** Step 4 of First run. Then create ADMIN / ACCOUNTS / EXECUTIVE logins in dashboard > Users.
6. **WhatsApp and calls.** Nothing to connect. Buttons use click-to-chat for `+91 69004 95871`. A visitor must press Send; the site never claims a message was delivered. Appointment confirmations open a pre-written WhatsApp message that staff send.
7. **Backups.** Schedule a nightly `pg_dump` of the database and a copy of the uploads volume (or rely on R2). Test a restore once.

## Business rules built in
- First visit free; later visits are marked "fee pending" for staff to decide (refundable ₹500, subject to APD policy). Staff set the fee status per visit.
- Brokerage defaults to 2% of the final price on each sale record. Sales and brokerage are visible only to SUPER_ADMIN and ACCOUNTS.
- Visits only on non-Thursdays between 10:00 AM and 5:00 PM (IST). Office address and hours are editable in Site settings.
- Owner name/phone are stored on the property record for staff only. Public endpoints never return them.
- Rentals, commercial property and land are not part of the data model.

## Things to check or decide before launch
- **Zones:** the grouping of localities into 5 zones is a starting guess. Review it in Admin > Localities.
- **Brokerage and visit fee are not shown on the public site.** Say so if you want them published.
- **Content-Security-Policy** allows inline scripts because the existing page uses them, plus Tailwind and GSAP from CDNs. For a tighter setup, self-host those files.
- Not included: SMS/email sending, online payments, per-executive logins restricted to only their own visits, password reset by email, two-factor login.
- Run `npm audit` and keep dependencies updated. Have the server reviewed before handling real customer data.

## Test checklist (do all before announcing)
Pages and links · property search and every filter · locality click shows only that locality · compare 2-3 flats · EMI calculator · admin login and wrong-password lockout · add/edit/delete property · upload JPG, MP4 and a wrong file type (must be rejected) · enquiry saves and shows in dashboard · status change, note, follow-up date · visit request on a Thursday (must be rejected) and on a valid day · second visit by same phone shows fee pending · each role sees only its tabs · public `/api/properties` JSON contains no owner phone · mobile and desktop layouts · restart the containers and confirm data is still there.

## API summary
Public: `GET /api/localities`, `/api/categories`, `/api/properties`, `/api/properties/:code`, `/api/settings`; `POST /api/enquiries`, `/api/appointments`. Admin (cookie + CSRF token): `/api/admin/*`.
