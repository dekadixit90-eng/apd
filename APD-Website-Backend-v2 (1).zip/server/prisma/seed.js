// Runs on every start but only fills EMPTY tables, so your later edits are never overwritten.
import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
const p = new PrismaClient();
const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
// Zone grouping is a starting point: review and correct it in Admin > Localities.
const ZONES = {
  'East Guwahati': ['Noonmati', 'Narengi', 'Satgaon'],
  'Central Guwahati': ['Chandmari', 'Rajgarh', 'Zoo Road', 'Zoo Tiniali', 'Silpukhuri', 'Bamunimaidam', 'Geetanagar', 'Japorigog', 'Mathgharia', 'Patharquarry', 'Downtown', 'Bhangagarh', 'Ulubari', 'Paltan Bazar', 'Panbazar', 'Fancy Bazar', 'Bharalumukh', 'Guwahati Club', 'Ambari', 'Uzan Bazar'],
  'South Guwahati (Dispur & GS Road side)': ['Dispur', 'Ganeshguri', 'Six Mile', 'Khanapara', 'Jayanagar', 'VIP Road', 'Rukminigaon', 'Wireless', 'Lalmati', 'Sawkuchi', 'Ghoramara', 'Hatigaon', 'Jatia', 'Kahilipara', 'Hengrabari', 'Survey', 'Panjabari', 'Baghorbari', 'Christian Basti'],
  'South-East Guwahati (Beltola & Basistha side)': ['Beltola', 'Beltola Tiniali', 'Basistha', 'Lokhra', 'Borbari'],
  'West Guwahati': ['Maligaon', 'Jalukbari', 'Adabari', 'Pandu', 'Gotanagar', 'Lankeshwar', 'Azara', 'Garchuk', 'Dhirenpara', 'Fatasil Ambari', 'Lal Ganesh']
};
try {
  if (await p.locality.count() === 0) {
    await p.locality.createMany({ data: Object.entries(ZONES).flatMap(([zone, names]) => names.map(name => ({ name, slug: slug(name), zone }))) });
    console.log('Seeded localities');
  }
  if (await p.category.count() === 0) await p.category.createMany({ data: [{ name: 'Apartment' }, { name: 'Duplex apartment' }] });
  const defaults = {
    officeAddress: 'Eastern Hut, Flat No. 103, 1st Floor, Near WOW! Momo, Noonmati Bus Stop, Noonmati, Guwahati, Assam – 781020',
    officeHours: '10:00 AM to 5:00 PM · Sunday open · Thursday closed',
    announcement: ''
  };
  for (const [key, value] of Object.entries(defaults)) await p.setting.upsert({ where: { key }, update: {}, create: { key, value } });
} finally { await p.$disconnect(); }
