// Shared validation + business rules (used by public and admin routes)
import { z } from 'zod';
import { prisma } from './db.js';

export class Bad extends Error {}
export const parse = (schema, body) => {
  const p = schema.safeParse(body);
  if (!p.success) throw new Bad(p.error.issues.map(i => (i.path.join('.') || 'input') + ': ' + i.message).join('; '));
  return p.data;
};

const blank = v => (v === '' || v == null ? null : v);
export const optStr = (n = 200) => z.preprocess(blank, z.string().trim().max(n).nullable());
export const optInt = z.preprocess(blank, z.coerce.number().int().min(0).nullable());

// Indian mobile -> stored as the 10-digit number so enquiry history can match by phone
export const phoneS = z.string()
  .transform(s => s.replace(/[\s()-]/g, ''))
  .refine(s => /^(\+?91|0)?[6-9]\d{9}$/.test(s), 'Enter a valid 10-digit Indian mobile number')
  .transform(s => s.slice(-10));

export const enquiryS = z.object({
  name: z.string().trim().min(2).max(100),
  phone: phoneS,
  email: z.preprocess(blank, z.string().email().max(150).nullable()),
  locality: optStr(100), budget: optStr(60), bedrooms: optStr(30), area: optStr(60),
  propertyCode: optStr(30), details: optStr(2000),
  kind: z.enum(['BUY', 'SELL']).default('BUY'),
  website: z.string().optional() // honeypot: real people leave this empty
});

export const apptS = z.object({
  name: z.string().trim().min(2).max(100),
  phone: phoneS,
  preferredAt: z.string().min(10).max(40),
  propertyCode: optStr(30), location: optStr(100), requirements: optStr(1000),
  website: z.string().optional()
});

const OFFICE_CLOSED_DAY = 4; // Thursday
export async function createAppointment(d, { admin = false } = {}) {
  const hasTz = /(Z|[+-]\d\d:?\d\d)$/.test(d.preferredAt);
  const iso = hasTz ? d.preferredAt : (d.preferredAt.length === 16 ? d.preferredAt + ':00' : d.preferredAt) + '+05:30'; // IST
  const at = new Date(iso);
  if (isNaN(at)) throw new Bad('Choose a valid visit date and time');
  if (!admin) {
    const ist = new Date(at.getTime() + 19800000);
    if (at < new Date()) throw new Bad('Choose a future date and time');
    if (ist.getUTCDay() === OFFICE_CLOSED_DAY) throw new Bad('Our office is closed on Thursdays. Please pick another day.');
    const h = ist.getUTCHours();
    if (h < 10 || h >= 17) throw new Bad('Visits are available between 10:00 AM and 5:00 PM.');
  }
  const prior = await prisma.appointment.count({ where: { phone: d.phone, status: { not: 'CANCELLED' } } });
  const enq = await prisma.enquiry.findFirst({ where: { phone: d.phone }, orderBy: { createdAt: 'desc' }, select: { id: true } });
  const a = await prisma.appointment.create({ data: {
    name: d.name, phone: d.phone, preferredAt: at, propertyCode: d.propertyCode, location: d.location,
    requirements: d.requirements, feeRequired: prior > 0, feeStatus: prior > 0 ? 'PENDING' : 'NOT_REQUIRED', enquiryId: enq?.id
  } });
  const note = prior > 0
    ? 'A refundable ₹500 registration/visit fee may apply for additional visits, subject to APD policy. APD will confirm with you.'
    : 'Your first property visit is free.';
  return { a, note };
}
