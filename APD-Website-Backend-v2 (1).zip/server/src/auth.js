import crypto from 'node:crypto';
import argon2 from 'argon2';
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { prisma } from './db.js';

// Role -> areas. 'x' = read+write, 'x:read' = read only, '*' = everything.
const PERMS = {
  SUPER_ADMIN: ['*'],
  ADMIN: ['properties', 'localities', 'categories', 'enquiries', 'appointments', 'staff', 'reports', 'settings'],
  ACCOUNTS: ['sales', 'reports', 'properties:read'],
  EXECUTIVE: ['appointments', 'enquiries:read', 'properties:read', 'staff:read']
};
export const AREAS = ['properties', 'localities', 'categories', 'enquiries', 'appointments', 'staff', 'sales', 'reports', 'settings', 'users'];
export const access = (role, area) => {
  const p = PERMS[role] || [];
  return p.includes('*') || p.includes(area) ? 'rw' : p.includes(area + ':read') ? 'r' : null;
};
export const need = area => (q, r, n) => {
  const a = access(q.admin.role, area);
  return a === 'rw' || (a === 'r' && q.method === 'GET') ? n() : r.status(403).json({ error: 'Your role cannot do this' });
};

const sha = t => crypto.createHash('sha256').update(t).digest('hex');
const cookie = (q, name) => (q.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith(name + '='))?.slice(name.length + 1);
const setCookie = (v, age) => `apd_session=${v}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`;
const me = (u, csrf) => ({ username: u.username, role: u.role, csrf, access: Object.fromEntries(AREAS.map(a => [a, access(u.role, a)])) });

export async function auth(q, r, n) {
  const t = cookie(q, 'apd_session');
  const s = t && await prisma.session.findUnique({ where: { id: sha(t) }, include: { user: true } });
  if (!s || s.expiresAt < new Date() || !s.user.active) return r.status(401).json({ error: 'Sign in required' });
  if (q.method !== 'GET' && q.headers['x-csrf-token'] !== s.csrf) return r.status(403).json({ error: 'Security token mismatch. Refresh the page and try again.' });
  q.admin = s.user; q.session = s; n();
}

export const authRouter = Router();
authRouter.post('/login', rateLimit({ windowMs: 900000, limit: 10, message: { error: 'Too many sign-in attempts. Try again in 15 minutes.' } }), async (q, r) => {
  const u = await prisma.adminUser.findUnique({ where: { username: String(q.body.username || '') } });
  const ok = u && u.active && await argon2.verify(u.passwordHash, String(q.body.password || ''));
  if (!ok) return r.status(401).json({ error: 'Invalid sign-in' });
  const token = crypto.randomBytes(32).toString('hex'), csrf = crypto.randomBytes(24).toString('hex');
  await prisma.session.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  await prisma.session.create({ data: { id: sha(token), userId: u.id, csrf, expiresAt: new Date(Date.now() + 8 * 3600e3) } });
  r.setHeader('Set-Cookie', setCookie(token, 28800));
  r.json(me(u, csrf));
});
authRouter.get('/me', auth, (q, r) => r.json(me(q.admin, q.session.csrf)));
authRouter.post('/logout', auth, async (q, r) => {
  await prisma.session.delete({ where: { id: q.session.id } });
  r.setHeader('Set-Cookie', setCookie('', 0));
  r.json({ ok: true });
});
