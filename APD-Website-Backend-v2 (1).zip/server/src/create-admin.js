// Usage: node src/create-admin.js <username> [role]   (password is asked interactively; role defaults to SUPER_ADMIN)
import 'dotenv/config';
import argon2 from 'argon2';
import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { prisma } from './db.js';

const rl = readline.createInterface({ input: stdin, output: stdout });
try {
  const username = process.argv[2] || await rl.question('Admin username: ');
  const role = (process.argv[3] || 'SUPER_ADMIN').toUpperCase();
  if (!['SUPER_ADMIN', 'ADMIN', 'ACCOUNTS', 'EXECUTIVE'].includes(role)) throw Error('Role must be SUPER_ADMIN, ADMIN, ACCOUNTS or EXECUTIVE');
  const password = process.env.ADMIN_PASSWORD || await rl.question('Password (14+ characters): ');
  if (password.length < 14) throw Error('Use at least 14 characters');
  const passwordHash = await argon2.hash(password);
  await prisma.adminUser.upsert({ where: { username }, update: { passwordHash, role, active: true }, create: { username, passwordHash, role } });
  console.log(`Account "${username}" saved with role ${role}`);
} finally { rl.close(); await prisma.$disconnect(); }
