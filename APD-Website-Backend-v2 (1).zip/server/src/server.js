import 'dotenv/config';
import 'express-async-errors';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { z } from 'zod';
import { prisma } from './db.js';
import { auth, authRouter } from './auth.js';
import { admin, UPLOAD_DIR, PUBLIC_SETTINGS } from './admin.js';
import { Bad, parse, enquiryS, apptS, createAppointment } from './rules.js';

const prod = process.env.NODE_ENV === 'production';
const app = express();
app.set('trust proxy', 1); // behind Caddy/nginx so rate limits see real visitor IPs
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"],
  // The existing page uses inline scripts/handlers plus Tailwind + GSAP from CDNs. Self-host them later to tighten this.
  scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com', 'https://cdnjs.cloudflare.com'],
  scriptSrcAttr: ["'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:', 'https:'],
  mediaSrc: ["'self'", 'https:'],
  connectSrc: ["'self'"],
  objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"],
  upgradeInsecureRequests: prod ? [] : null
} } }));
app.use(express.json({ limit: '200kb' }));
app.use('/api/', rateLimit({ windowMs: 900000, limit: 400 }));
const formLimit = rateLimit({ windowMs: 3600000, limit: 15, message: { error: 'Too many submissions from this device. Please call or WhatsApp APD instead.' } });

app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d', index: false }));
app.use(express.static(path.resolve('./public')));

// ---------- public API (never returns owner name/phone) ----------
const toPublic = p => ({
  code: p.propertyCode, title: p.title, price: Number(p.price), bhk: p.bhk, bathrooms: p.bathrooms,
  carpetArea: p.carpetAreaSqFt, superBuiltUp: p.superBuiltUpSqFt, floor: p.floor, lift: p.lift, parking: p.parking,
  furnishing: p.furnishing, ageYears: p.ageYears, amenities: p.amenities, description: p.description, status: p.status, featured: p.featured,
  locality: { name: p.locality.name, slug: p.locality.slug, zone: p.locality.zone }, category: p.category?.name || null,
  media: p.media.map(m => ({ url: m.url, kind: m.kind }))
});
const pubInc = { locality: true, category: true, media: { orderBy: { sort: 'asc' } } };
const STATUSES = ['AVAILABLE', 'UNDER_NEGOTIATION', 'BOOKED', 'SOLD'];

app.get('/api/health', (_q, r) => r.json({ ok: true }));
app.get('/api/localities', async (_q, r) => {
  const l = await prisma.locality.findMany({ where: { active: true }, orderBy: { name: 'asc' }, include: { _count: { select: { properties: { where: { status: 'AVAILABLE' } } } } } });
  r.json(l.map(x => ({ name: x.name, slug: x.slug, zone: x.zone, availableCount: x._count.properties })));
});
app.get('/api/categories', async (_q, r) => r.json((await prisma.category.findMany({ where: { active: true }, orderBy: { name: 'asc' } })).map(c => c.name)));
app.get('/api/properties', async (q, r) => {
  const where = { status: { in: STATUSES }, locality: { active: true } };
  if (q.query.locality) where.locality = { active: true, slug: String(q.query.locality) };
  if (STATUSES.includes(q.query.status)) where.status = q.query.status;
  if (q.query.category) where.category = { name: String(q.query.category) };
  const min = Number(q.query.minPrice), max = Number(q.query.maxPrice), bhk = Number(q.query.bhk), area = Number(q.query.minArea);
  if (min || max) where.price = { ...(min && { gte: min }), ...(max && { lte: max }) };
  if (bhk) where.bhk = { gte: bhk };
  if (area) where.OR = [{ carpetAreaSqFt: { gte: area } }, { superBuiltUpSqFt: { gte: area } }];
  const rows = await prisma.property.findMany({ where, include: pubInc, orderBy: [{ featured: 'desc' }, { createdAt: 'desc' }], take: 300 });
  r.json(rows.map(toPublic));
});
app.get('/api/properties/:code', async (q, r) => {
  const p = await prisma.property.findFirst({ where: { propertyCode: q.params.code, status: { in: STATUSES } }, include: pubInc });
  p ? r.json(toPublic(p)) : r.status(404).json({ error: 'Property not found' });
});
app.get('/api/settings', async (_q, r) => r.json(Object.fromEntries((await prisma.setting.findMany({ where: { key: { in: PUBLIC_SETTINGS } } })).map(s => [s.key, s.value]))));

app.post('/api/enquiries', formLimit, async (q, r) => {
  const { website, ...d } = parse(enquiryS, q.body);
  if (website) return r.status(201).json({ ok: true }); // bot: pretend success, store nothing
  const e = await prisma.enquiry.create({ data: d });
  r.status(201).json({ ok: true, id: e.id });
});
app.post('/api/appointments', formLimit, async (q, r) => {
  const { website, ...d } = parse(apptS, q.body);
  if (website) return r.status(201).json({ ok: true, note: '' });
  const { a, note } = await createAppointment(d);
  r.status(201).json({ ok: true, id: a.id, note });
});

// ---------- admin ----------
app.use('/api/admin', authRouter);
app.use('/api/admin', auth, admin);
app.get('/admin', (_q, r) => r.sendFile(path.resolve('./public/admin.html')));

app.use('/api', (_q, r) => r.status(404).json({ error: 'Not found' }));
app.use((e, _q, r, _n) => {
  if (e instanceof Bad) return r.status(400).json({ error: e.message });
  if (e?.code === 'P2002') return r.status(409).json({ error: 'That value already exists. Please use a different one.' });
  if (e?.code === 'P2025') return r.status(404).json({ error: 'Record not found' });
  if (e?.code === 'P2003') return r.status(409).json({ error: 'This record is used by other records. Deactivate it instead of deleting.' });
  if (e?.name === 'MulterError') return r.status(400).json({ error: e.message });
  if (e?.type === 'entity.parse.failed') return r.status(400).json({ error: 'Bad request' });
  console.error(e);
  r.status(500).json({ error: 'Something went wrong. Please try again.' });
});
app.listen(process.env.PORT || 3000, () => console.log('APD server running'));
