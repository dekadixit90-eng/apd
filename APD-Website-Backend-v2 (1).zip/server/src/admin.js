import { Router } from 'express';
import multer from 'multer';
import argon2 from 'argon2';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import { prisma } from './db.js';
import { need, access } from './auth.js';
import { Bad, parse, optStr, optInt, apptS, createAppointment } from './rules.js';

export const UPLOAD_DIR = process.env.UPLOAD_DIR || path.resolve('./uploads');
const R2 = process.env.R2_BUCKET && process.env.R2_ACCOUNT_ID && process.env.R2_ACCESS_KEY_ID && process.env.R2_SECRET_ACCESS_KEY && process.env.R2_PUBLIC_URL;
const okUrl = u => !u.includes('..') && (u.startsWith('/uploads/') || (R2 && u.startsWith(process.env.R2_PUBLIC_URL.replace(/\/$/, '') + '/')));

export const admin = Router();
// Audit trail: who did what (method + path only; request bodies are never logged)
admin.use((q, r, n) => {
  if (q.method !== 'GET') r.on('finish', () => { if (r.statusCode < 400) prisma.auditLog.create({ data: { adminId: q.admin.id, action: q.method, entity: q.originalUrl.slice(0, 200) } }).catch(() => {}); });
  n();
});

// ---------- generic CRUD for simple tables ----------
const slugify = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
function crud(route, model, area, schema, { orderBy, include } = {}) {
  admin.get(route, need(area), async (q, r) => r.json(await prisma[model].findMany({ orderBy, include })));
  admin.post(route, need(area), async (q, r) => r.status(201).json(await prisma[model].create({ data: parse(schema, q.body) })));
  admin.put(route + '/:id', need(area), async (q, r) => r.json(await prisma[model].update({ where: { id: q.params.id }, data: parse(schema, q.body) })));
  admin.delete(route + '/:id', need(area), async (q, r) => { await prisma[model].delete({ where: { id: q.params.id } }); r.json({ ok: true }); });
}
crud('/localities', 'locality', 'localities',
  z.object({ name: z.string().trim().min(2).max(80), zone: z.string().trim().min(2).max(80), active: z.boolean().default(true) }).transform(d => ({ ...d, slug: slugify(d.name) })),
  { orderBy: { name: 'asc' }, include: { _count: { select: { properties: true } } } });
crud('/categories', 'category', 'categories', z.object({ name: z.string().trim().min(2).max(60), active: z.boolean().default(true) }), { orderBy: { name: 'asc' } });
crud('/staff', 'staff', 'staff',
  z.object({ name: z.string().trim().min(2).max(100), phone: z.string().trim().min(7).max(20), area: optStr(100), responsibilities: optStr(500), active: z.boolean().default(true) }),
  { orderBy: { name: 'asc' } });

// ---------- properties ----------
const propS = z.object({
  propertyCode: z.string().trim().min(2).max(30).regex(/^[A-Za-z0-9-]+$/, 'letters, numbers and dashes only'),
  title: z.string().trim().min(3).max(150),
  localityId: z.string().min(1, 'choose a locality'), categoryId: optStr(40),
  price: z.coerce.number().positive().max(1e10),
  bhk: z.coerce.number().int().min(1).max(10), bathrooms: z.coerce.number().int().min(0).max(10),
  carpetAreaSqFt: optInt, superBuiltUpSqFt: optInt, floor: optInt, ageYears: optInt,
  lift: z.boolean().default(false), parking: optStr(100),
  furnishing: z.enum(['UNFURNISHED', 'SEMI_FURNISHED', 'FURNISHED']).default('UNFURNISHED'),
  amenities: z.array(z.string().trim().max(60)).max(40).default([]),
  description: z.string().trim().min(10).max(5000),
  status: z.enum(['DRAFT', 'AVAILABLE', 'UNDER_NEGOTIATION', 'BOOKED', 'SOLD']).default('DRAFT'),
  featured: z.boolean().default(false),
  ownerName: optStr(100), ownerPhone: optStr(20),
  media: z.array(z.object({ url: z.string().max(500).refine(okUrl, 'unknown media location'), kind: z.enum(['IMAGE', 'VIDEO']) })).max(30).default([])
});
const inc = { locality: true, category: true, media: { orderBy: { sort: 'asc' } } };
const mediaCreate = m => ({ create: m.map((x, i) => ({ ...x, sort: i })) });
admin.get('/properties', need('properties'), async (q, r) => {
  const s = String(q.query.q || '').trim();
  r.json(await prisma.property.findMany({
    where: s ? { OR: [{ propertyCode: { contains: s, mode: 'insensitive' } }, { title: { contains: s, mode: 'insensitive' } }] } : {},
    include: inc, orderBy: { createdAt: 'desc' }
  }));
});
admin.post('/properties', need('properties'), async (q, r) => {
  const { media, ...d } = parse(propS, q.body);
  r.status(201).json(await prisma.property.create({ data: { ...d, media: mediaCreate(media) }, include: inc }));
});
admin.put('/properties/:id', need('properties'), async (q, r) => {
  const { media, ...d } = parse(propS, q.body);
  const [, p] = await prisma.$transaction([
    prisma.propertyMedia.deleteMany({ where: { propertyId: q.params.id } }),
    prisma.property.update({ where: { id: q.params.id }, data: { ...d, media: mediaCreate(media) }, include: inc })
  ]);
  r.json(p);
});
admin.delete('/properties/:id', need('properties'), async (q, r) => { await prisma.property.delete({ where: { id: q.params.id } }); r.json({ ok: true }); });

// ---------- uploads (images/videos) -> Cloudflare R2 if configured, else local disk ----------
const MIME = { 'image/jpeg': ['jpg', 'IMAGE'], 'image/png': ['png', 'IMAGE'], 'image/webp': ['webp', 'IMAGE'], 'video/mp4': ['mp4', 'VIDEO'], 'video/webm': ['webm', 'VIDEO'] };
const sniff = b => b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF ? 'image/jpeg'
  : b.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47])) ? 'image/png'
  : b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' ? 'image/webp'
  : b.subarray(4, 8).toString() === 'ftyp' ? 'video/mp4'
  : b.subarray(0, 4).equals(Buffer.from([0x1A, 0x45, 0xDF, 0xA3])) ? 'video/webm' : null;
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024, files: 10 } });
admin.post('/uploads', need('properties'), upload.array('files', 10), async (q, r) => {
  if (!q.files?.length) throw new Bad('Choose at least one file');
  const out = [];
  for (const f of q.files) {
    const mime = sniff(f.buffer);
    if (!mime || !MIME[mime]) throw new Bad(`${f.originalname}: only JPG, PNG, WebP, MP4 or WebM files are allowed`);
    const [ext, kind] = MIME[mime], name = `${crypto.randomUUID()}.${ext}`; // never trust the uploaded filename
    if (R2) {
      const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
      const s3 = new S3Client({ region: 'auto', endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`, credentials: { accessKeyId: process.env.R2_ACCESS_KEY_ID, secretAccessKey: process.env.R2_SECRET_ACCESS_KEY } });
      await s3.send(new PutObjectCommand({ Bucket: process.env.R2_BUCKET, Key: `uploads/${name}`, Body: f.buffer, ContentType: mime }));
      out.push({ url: `${process.env.R2_PUBLIC_URL.replace(/\/$/, '')}/uploads/${name}`, kind });
    } else {
      await fs.mkdir(UPLOAD_DIR, { recursive: true });
      await fs.writeFile(path.join(UPLOAD_DIR, name), f.buffer);
      out.push({ url: `/uploads/${name}`, kind });
    }
  }
  r.status(201).json(out);
});

// ---------- enquiries / CRM ----------
const ENQ = ['NEW', 'CONTACTED', 'FOLLOW_UP', 'SITE_VISIT_SCHEDULED', 'CONVERTED', 'CLOSED'];
admin.get('/enquiries', need('enquiries'), async (q, r) => {
  const where = {}, s = String(q.query.q || '').trim();
  if (ENQ.includes(q.query.status)) where.status = q.query.status;
  if (['BUY', 'SELL'].includes(q.query.kind)) where.kind = q.query.kind;
  if (q.query.due) { where.followUpDate = { lte: new Date(Date.now() + 86400000) }; where.status = { notIn: ['CONVERTED', 'CLOSED'] }; }
  if (s) where.OR = ['name', 'phone', 'propertyCode', 'locality'].map(k => ({ [k]: { contains: s, mode: 'insensitive' } }));
  r.json(await prisma.enquiry.findMany({ where, orderBy: { createdAt: 'desc' }, take: 500, include: { _count: { select: { notes: true } } } }));
});
admin.get('/enquiries/:id', need('enquiries'), async (q, r) => {
  const e = await prisma.enquiry.findUnique({ where: { id: q.params.id }, include: { notes: { orderBy: { createdAt: 'desc' } }, appointments: true } });
  if (!e) throw Object.assign(new Error(), { code: 'P2025' });
  const history = await prisma.enquiry.findMany({ where: { phone: e.phone, id: { not: e.id } }, orderBy: { createdAt: 'desc' }, select: { id: true, createdAt: true, status: true, propertyCode: true, locality: true } });
  r.json({ ...e, history });
});
admin.patch('/enquiries/:id', need('enquiries'), async (q, r) => {
  const d = parse(z.object({ status: z.enum(ENQ).optional(), followUpDate: z.preprocess(v => v === '' ? null : v, z.coerce.date().nullable()).optional() }), q.body);
  r.json(await prisma.enquiry.update({ where: { id: q.params.id }, data: d }));
});
admin.post('/enquiries/:id/notes', need('enquiries'), async (q, r) => {
  const { text } = parse(z.object({ text: z.string().trim().min(1).max(2000) }), q.body);
  r.status(201).json(await prisma.enquiryNote.create({ data: { enquiryId: q.params.id, authorName: q.admin.username, text } }));
});
admin.delete('/enquiries/:id', need('enquiries'), async (q, r) => { await prisma.enquiry.delete({ where: { id: q.params.id } }); r.json({ ok: true }); });

// ---------- appointments ----------
const APPT = ['REQUESTED', 'CONFIRMED', 'RESCHEDULED', 'COMPLETED', 'CANCELLED'];
admin.get('/appointments', need('appointments'), async (q, r) => {
  const where = {};
  if (APPT.includes(q.query.status)) where.status = q.query.status;
  if (q.query.staffId) where.staffId = String(q.query.staffId);
  if (q.query.from || q.query.to) where.preferredAt = { ...(q.query.from && { gte: new Date(q.query.from) }), ...(q.query.to && { lt: new Date(new Date(q.query.to).getTime() + 86400000) }) };
  r.json(await prisma.appointment.findMany({ where, include: { staff: true }, orderBy: { preferredAt: 'asc' }, take: 1000 }));
});
admin.post('/appointments', need('appointments'), async (q, r) => {
  const { website, ...d } = parse(apptS, q.body);
  r.status(201).json((await createAppointment(d, { admin: true })).a);
});
admin.patch('/appointments/:id', need('appointments'), async (q, r) => {
  const d = parse(z.object({
    status: z.enum(APPT).optional(), preferredAt: z.coerce.date().optional(), staffId: optStr(40).optional(),
    feeStatus: z.enum(['NOT_REQUIRED', 'PENDING', 'PAID', 'REFUNDED']).optional(), adminNote: optStr(1000).optional()
  }), q.body);
  if (d.staffId && !(await prisma.staff.findFirst({ where: { id: d.staffId, active: true } }))) throw new Bad('Choose an active staff member');
  const a = await prisma.appointment.update({ where: { id: q.params.id }, data: d, include: { staff: true } });
  if (a.enquiryId && ['CONFIRMED', 'RESCHEDULED'].includes(a.status)) await prisma.enquiry.update({ where: { id: a.enquiryId }, data: { status: 'SITE_VISIT_SCHEDULED' } });
  r.json(a);
});
admin.delete('/appointments/:id', need('appointments'), async (q, r) => { await prisma.appointment.delete({ where: { id: q.params.id } }); r.json({ ok: true }); });

// ---------- sales & brokerage (ACCOUNTS / SUPER_ADMIN only) ----------
const saleS = z.object({
  propertyId: z.string().min(1), buyerName: z.string().trim().min(2).max(100), buyerPhone: optStr(20),
  finalPrice: z.coerce.number().positive(), brokeragePct: z.coerce.number().min(0).max(10).default(2),
  brokerageStatus: z.enum(['PENDING', 'RECEIVED']).default('PENDING'), saleDate: z.coerce.date(),
  notes: optStr(1000), markSold: z.boolean().default(true)
});
const money2 = (p, pct) => +(p * pct / 100).toFixed(2);
const saleInc = { property: { select: { propertyCode: true, title: true } } };
admin.get('/sales', need('sales'), async (q, r) => r.json(await prisma.sale.findMany({ include: saleInc, orderBy: { saleDate: 'desc' } })));
admin.post('/sales', need('sales'), async (q, r) => {
  const { markSold, ...d } = parse(saleS, q.body);
  const ops = [prisma.sale.create({ data: { ...d, brokerageAmount: money2(d.finalPrice, d.brokeragePct) }, include: saleInc })];
  if (markSold) ops.push(prisma.property.update({ where: { id: d.propertyId }, data: { status: 'SOLD' } }));
  r.status(201).json((await prisma.$transaction(ops))[0]);
});
admin.put('/sales/:id', need('sales'), async (q, r) => {
  const { markSold, ...d } = parse(saleS, q.body);
  r.json(await prisma.sale.update({ where: { id: q.params.id }, data: { ...d, brokerageAmount: money2(d.finalPrice, d.brokeragePct) }, include: saleInc }));
});
admin.delete('/sales/:id', need('sales'), async (q, r) => { await prisma.sale.delete({ where: { id: q.params.id } }); r.json({ ok: true }); });

// ---------- reports ----------
admin.get('/reports', need('reports'), async (q, r) => {
  const year = Number(q.query.year) || new Date().getFullYear();
  const from = new Date(Date.UTC(year, 0, 1)), to = new Date(Date.UTC(year + 1, 0, 1));
  const by = async (model, field) => Object.fromEntries((await prisma[model].groupBy({ by: [field], _count: true })).map(x => [x[field], x._count]));
  const monthly = (table, col) => prisma.$queryRawUnsafe(`SELECT to_char(date_trunc('month',"${col}"),'MM') AS m, count(*)::int AS c FROM "${table}" WHERE "${col}">=$1 AND "${col}"<$2 GROUP BY 1 ORDER BY 1`, from, to);
  const out = {
    year,
    properties: await by('property', 'status'),
    enquiries: await by('enquiry', 'status'),
    appointments: await by('appointment', 'status'),
    monthly: { enquiries: await monthly('Enquiry', 'createdAt'), appointments: await monthly('Appointment', 'preferredAt') },
    staff: (await prisma.staff.findMany({ include: { appointments: { select: { status: true } } } })).map(s => ({ name: s.name, assigned: s.appointments.length, completed: s.appointments.filter(a => a.status === 'COMPLETED').length }))
  };
  if (access(q.admin.role, 'sales')) {
    const sales = await prisma.sale.findMany({ where: { saleDate: { gte: from, lt: to } } });
    const sum = (a, k) => a.reduce((t, x) => t + Number(x[k]), 0);
    out.sales = { count: sales.length, value: sum(sales, 'finalPrice'), brokerage: sum(sales, 'brokerageAmount'), brokerageReceived: sum(sales.filter(s => s.brokerageStatus === 'RECEIVED'), 'brokerageAmount') };
    out.monthly.sales = Array.from({ length: 12 }, (_, i) => { const m = sales.filter(s => s.saleDate.getUTCMonth() === i); return { m: String(i + 1).padStart(2, '0'), c: m.length, value: sum(m, 'finalPrice'), brokerage: sum(m, 'brokerageAmount') }; }).filter(x => x.c);
  }
  r.json(out);
});

// ---------- users (SUPER_ADMIN only) ----------
const pw = z.string().min(14, 'Use at least 14 characters').max(200);
const ROLES = ['SUPER_ADMIN', 'ADMIN', 'ACCOUNTS', 'EXECUTIVE'];
admin.get('/users', need('users'), async (q, r) => r.json(await prisma.adminUser.findMany({ select: { id: true, username: true, role: true, active: true, createdAt: true }, orderBy: { createdAt: 'asc' } })));
admin.post('/users', need('users'), async (q, r) => {
  const d = parse(z.object({ username: z.string().trim().regex(/^[a-zA-Z0-9._-]{3,40}$/, '3-40 letters, numbers . _ -'), password: pw, role: z.enum(ROLES) }), q.body);
  const u = await prisma.adminUser.create({ data: { username: d.username, role: d.role, passwordHash: await argon2.hash(d.password) } });
  r.status(201).json({ id: u.id, username: u.username, role: u.role });
});
admin.put('/users/:id', need('users'), async (q, r) => {
  const d = parse(z.object({ role: z.enum(ROLES).optional(), active: z.boolean().optional(), password: z.preprocess(v => v === '' ? undefined : v, pw.optional()) }), q.body);
  if (q.params.id === q.admin.id && (d.active === false || (d.role && d.role !== q.admin.role))) throw new Bad('You cannot change your own role or deactivate yourself');
  const data = { role: d.role, active: d.active };
  if (d.password) data.passwordHash = await argon2.hash(d.password);
  const u = await prisma.adminUser.update({ where: { id: q.params.id }, data });
  if (d.password || d.active === false) await prisma.session.deleteMany({ where: { userId: u.id } });
  r.json({ id: u.id, username: u.username, role: u.role, active: u.active });
});
admin.delete('/users/:id', need('users'), async (q, r) => {
  if (q.params.id === q.admin.id) throw new Bad('You cannot delete your own account');
  await prisma.adminUser.delete({ where: { id: q.params.id } }); r.json({ ok: true });
});

// ---------- site settings ----------
export const PUBLIC_SETTINGS = ['announcement', 'officeHours', 'officeAddress'];
admin.get('/settings', need('settings'), async (q, r) => r.json(Object.fromEntries((await prisma.setting.findMany()).map(s => [s.key, s.value]))));
admin.put('/settings', need('settings'), async (q, r) => {
  const d = parse(z.object({ announcement: z.string().max(300), officeHours: z.string().max(200), officeAddress: z.string().max(400) }).partial(), q.body);
  for (const [key, value] of Object.entries(d)) await prisma.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
  r.json({ ok: true });
});
