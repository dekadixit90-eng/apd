/* Connects the existing APD page to the live backend (/api/*).
   If the server is not reachable (e.g. you opened the file directly), it falls back to the old demo cards and says so. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SL = { AVAILABLE: 'Available', UNDER_NEGOTIATION: 'Under negotiation', BOOKED: 'Booked', SOLD: 'Sold' };
const FUR = { UNFURNISHED: 'Unfurnished', SEMI_FURNISHED: 'Semi-furnished', FURNISHED: 'Furnished' };
window.APD_STATUS = SL;
const DEMO = properties.map(p => ({ ...p }));
const PH = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 260"><rect width="400" height="260" fill="#0d2038"/><g fill="#c6a46a" opacity=".85"><rect x="150" y="70" width="100" height="140"/><rect x="260" y="110" width="60" height="100"/></g><g fill="#0d2038"><rect x="164" y="88" width="14" height="18"/><rect x="190" y="88" width="14" height="18"/><rect x="216" y="88" width="14" height="18"/><rect x="164" y="122" width="14" height="18"/><rect x="190" y="122" width="14" height="18"/><rect x="216" y="122" width="14" height="18"/></g></svg>');
let LOCS = [], live = false, letter = '';

async function j(u, o) {
  const r = await fetch(u, o), d = await r.json().catch(() => ({}));
  if (!r.ok) throw Error(d.error || 'Request failed');
  return d;
}
const post = (u, b) => j(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) });
const map = (p, i) => ({
  id: i + 1, code: p.code, name: esc(p.title), location: esc(p.locality.name), type: esc(p.category || 'Apartment'),
  beds: p.bhk, baths: p.bathrooms, area: p.carpetArea || p.superBuiltUp || 0, carpet: p.carpetArea, sbu: p.superBuiltUp,
  price: p.price, purpose: 'Buy', furnishing: FUR[p.furnishing] || '', parking: esc(p.parking || 'Not specified'),
  lift: p.lift, floor: p.floor, age: p.ageYears, amenities: (p.amenities || []).map(esc), media: p.media,
  image: (p.media.find(m => m.kind === 'IMAGE') || {}).url || '', desc: esc(p.description), status: p.status, featured: p.featured
});

/* ---------- WhatsApp message for a property (format requested by APD) ---------- */
window.enquiry = p => `Hello Assam Property Dealer, I am interested in this property.\n\nProperty Name: ${p.name.replace(/&amp;/g, '&')}\nLocation: ${p.location.replace(/&amp;/g, '&')}, Guwahati\nPrice: ${money(p.price)}\nProperty ID: ${p.code || 'N/A'}\n\nPlease share more details.`;

/* ---------- listing cards ---------- */
const empty = () => {
  const l = $('filterLocation').value;
  const msg = !live ? 'No demo listings match.' : !properties.length ? 'New flats will be listed here soon. Contact APD for the latest availability.' : l ? `No flats match these filters in ${esc(l)} right now.` : 'No flats match these filters.';
  return `<div class="col-span-full text-center py-16 muted">${msg}<br><a class="btn mt-4" target="_blank" rel="noopener" href="${waLink('Hello Assam Property Dealer, I am looking for a flat' + (l ? ' in ' + l : '') + '. Please share available options.')}">Ask APD on WhatsApp ↗</a></div>`;
};
const card = p => `<article class="property-card"><div class="property-image"><img loading="lazy" src="${esc(p.image || PH)}" alt="${p.name}">${p.featured ? '<span class="ft">FEATURED</span>' : ''}${live ? `<span class="st st-${p.status}">${SL[p.status]}</span>` : '<span class="demo-tag">DEMO</span>'}<span class="price-tag">${money(p.price)}</span><button class="fav ${favourites.has(p.id) ? 'active' : ''}" onclick="toggleFavourite(${p.id})" aria-label="Save to favourites">${favourites.has(p.id) ? '♥' : '♡'}</button></div><div class="property-body"><div class="property-loc">⌖ ${p.location}, Guwahati · ${p.type}${p.code ? ' · ' + esc(p.code) : ''}</div><h3>${p.name}</h3><p class="text-xs muted leading-6">${p.desc.length > 150 ? p.desc.slice(0, 147) + '…' : p.desc}</p><div class="property-meta"><span>▣ ${p.beds} BHK</span><span>▤ ${p.baths} Baths</span><span>⌗ ${p.area ? p.area.toLocaleString('en-IN') + ' sq.ft.' : 'Area on request'}</span></div><label class="text-xs muted flex items-center gap-2 mb-3"><input type="checkbox" ${compare.has(p.id) ? 'checked' : ''} onchange="toggleCompare(${p.id})"> Compare</label><div class="card-actions"><button class="small-outline" onclick="showDetails(${p.id})">View Details</button><a class="small-gold" href="${waLink(enquiry(p))}" target="_blank" rel="noopener">Enquire on WhatsApp</a></div></div></article>`;
window.renderProperties = function () {
  const arr = [...visible], s = $('sortProperties').value, rank = { AVAILABLE: 0, UNDER_NEGOTIATION: 1, BOOKED: 2, SOLD: 3 };
  if (s === 'low') arr.sort((a, b) => a.price - b.price);
  else if (s === 'high') arr.sort((a, b) => b.price - a.price);
  else arr.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || (rank[a.status] ?? 0) - (rank[b.status] ?? 0));
  $('resultCount').textContent = live ? `Showing ${arr.length} ${arr.length === 1 ? 'property' : 'properties'}` : `Showing ${arr.length} illustrative demo properties`;
  $('propertyGrid').innerHTML = arr.length ? arr.map(card).join('') : empty();
};
window.applyFilters = function () {
  const v = id => ($(id) || {}).value || '';
  const l = esc(v('filterLocation')), t = esc(v('filterType')), mx = +v('filterBudget') || 0, mn = +v('filterMin') || 0, b = +v('filterBeds') || 0, a = +v('filterArea') || 0, st = v('filterAvail');
  visible = properties.filter(p => (!l || p.location === l) && (!t || p.type === t) && (!mx || p.price <= mx) && (!mn || p.price >= mn) && (!b || p.beds >= b) && (!a || p.area >= a) && (!st || p.status === st));
  renderProperties(); $('properties').scrollIntoView({ behavior: 'smooth' });
};
window.clearFilters = function () {
  ['filterLocation', 'filterType', 'filterBudget', 'filterBeds', 'filterMin', 'filterArea', 'filterAvail'].forEach(i => { if ($(i)) $(i).value = ''; });
  visible = [...properties]; renderProperties();
};

/* ---------- details modal with photo/video gallery ---------- */
const medium = m => m.kind === 'VIDEO' ? `<video src="${esc(m.url)}" controls preload="metadata" style="width:100%;max-height:340px"></video>` : `<img src="${esc(m.url)}" alt="">`;
window.showDetails = function (id) {
  const p = properties.find(x => x.id === id); if (!p) return;
  const ms = p.media && p.media.length ? p.media : [{ url: p.image || PH, kind: 'IMAGE' }];
  const cell = (k, v) => v || v === 0 ? `<div class="bg-white/5 p-3">${k}<br><b>${v}</b></div>` : '';
  $('detailsContent').innerHTML = `<div class="eyebrow">${live ? esc(SL[p.status]).toUpperCase() + ' · ' + esc(p.code) : 'DEMO LISTING'}</div><div class="modal-grid mt-5"><div><div id="gMain">${medium(ms[0])}</div>${ms.length > 1 ? `<div class="gal">${ms.map((m, i) => m.kind === 'VIDEO' ? `<video src="${esc(m.url)}" muted preload="metadata" data-g="${i}"></video>` : `<img src="${esc(m.url)}" alt="" data-g="${i}">`).join('')}</div>` : ''}</div><div><div class="text-xs muted">${p.location}, Guwahati · ${p.type}</div><h2 class="serif text-3xl my-2">${p.name}</h2><div class="text-2xl gold mb-4">${money(p.price)}</div><p class="text-sm muted leading-7">${p.desc}</p><div class="grid grid-cols-2 gap-3 my-4 text-xs">${cell('Bedrooms', p.beds)}${cell('Bathrooms', p.baths)}${cell('Carpet area', p.carpet ? p.carpet.toLocaleString('en-IN') + ' sq.ft.' : '')}${cell('Super built-up', p.sbu ? p.sbu.toLocaleString('en-IN') + ' sq.ft.' : '')}${cell('Floor', p.floor)}${cell('Lift', p.lift === undefined ? '' : p.lift ? 'Yes' : 'No')}${cell('Furnishing', p.furnishing)}${cell('Property age', p.age != null ? p.age + ' yrs' : '')}</div><p class="text-xs muted mb-2"><b class="text-white">Amenities:</b> ${(p.amenities || []).join(', ') || 'Not listed'}</p><p class="text-xs muted mb-5"><b class="text-white">Parking:</b> ${p.parking}</p><a class="btn w-full" target="_blank" rel="noopener" href="${waLink(enquiry(p))}">Enquire on WhatsApp ↗</a></div></div><p class="muted text-xs mt-5">${live ? 'Please confirm price, availability and documents with APD before proceeding.' : 'Demo listing only. Not real inventory.'}</p>`;
  $('detailsContent').querySelectorAll('[data-g]').forEach(e => e.onclick = () => { $('gMain').innerHTML = medium(ms[+e.dataset.g]); });
  $('detailsBackdrop').classList.add('open');
};

/* ---------- locality directory ---------- */
function drawLocalities() {
  const q = ($('locSearch').value || '').toLowerCase().trim();
  const list = LOCS.filter(x => (!q || x.name.toLowerCase().includes(q)) && (!letter || x.name[0].toUpperCase() === letter));
  const letters = [...new Set(LOCS.map(x => x.name[0].toUpperCase()))].sort();
  $('locAZ').innerHTML = ['', ...letters].map(l => `<button class="${l === letter ? 'on' : ''}" data-l="${l}">${l || 'All'}</button>`).join('');
  const zones = {}; list.forEach(x => (zones[x.zone] = zones[x.zone] || []).push(x));
  $('locZones').innerHTML = Object.keys(zones).sort().map(z => `<div class="zone"><h3 class="serif">${esc(z)}</h3><div class="chips">${zones[z].map(x => `<button class="chip ${x.availableCount ? '' : 'zero'}" data-loc="${esc(x.name)}">${esc(x.name)} <em title="Flats currently available">${x.availableCount}</em></button>`).join('')}</div></div>`).join('') || '<p class="muted text-sm">No locality matches your search.</p>';
}
function fillSelects(cats) {
  const names = LOCS.map(x => x.name);
  $('filterLocation').innerHTML = '<option value="">All Guwahati</option>' + names.map(n => `<option>${esc(n)}</option>`).join('');
  $('filterType').innerHTML = '<option value="">All categories</option>' + cats.map(c => `<option>${esc(c)}</option>`).join('');
  const b = document.querySelector('#buyerEnquiryForm select[name=locality]'); if (b) b.innerHTML = '<option value="">Any Guwahati locality</option>' + names.map(n => `<option>${esc(n)}</option>`).join('');
  $('locList').innerHTML = names.map(n => `<option value="${esc(n)}">`).join('');
  window.LOC_NAMES = names.map(n => n.toLowerCase());
}
$('locSearch').addEventListener('input', drawLocalities);
$('locAZ').addEventListener('click', e => { if (e.target.dataset.l !== undefined) { letter = e.target.dataset.l; drawLocalities(); } });
$('locZones').addEventListener('click', e => { const b = e.target.closest('[data-loc]'); if (b) { clearFilters(); $('filterLocation').value = b.dataset.loc; applyFilters(); } });

/* ---------- forms: save to the database, then open WhatsApp; never claim delivery ---------- */
const WA_PHONE = '+91 69004 95871';
const validPhone = p => /^(\+?91|0)?[6-9]\d{9}$/.test(String(p).replace(/[\s()-]/g, ''));
function wire(id, handler) {
  const f = $(id), n = f.cloneNode(true); // clone drops the old demo-only listener
  n.insertAdjacentHTML('beforeend', '<input type="text" name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">');
  f.replaceWith(n); n.addEventListener('submit', handler); return n;
}
function noteFor(f) { let n = f.nextElementSibling; if (!n || !n.classList.contains('vmsg')) { n = document.createElement('div'); n.className = 'vmsg'; n.setAttribute('role', 'status'); f.after(n); } n.style.display = 'block'; return n; }
async function submitEnquiry(e, kind, body, msg) {
  e.preventDefault(); const f = e.target, btn = f.querySelector('button:not([type=button])'), note = noteFor(f);
  if (body.name.length < 2 || !validPhone(body.phone)) { note.textContent = 'Please enter your name and a valid 10-digit mobile number.'; return; }
  btn.disabled = true; let saved = false, err = '';
  try { await post('/api/enquiries', { kind, ...body, website: new FormData(f).get('website') || '' }); saved = true; } catch (x) { err = x.message; }
  btn.disabled = false;
  const url = waLink(msg);
  note.innerHTML = (saved ? 'Your enquiry has been saved with APD. ' : `We could not save your enquiry online (${esc(err)}). `) + `Your WhatsApp message is ready. Press <b>Send</b> in WhatsApp to message us${saved ? ' as well' : ''}, or call ${WA_PHONE}. <a href="${esc(url)}" target="_blank" rel="noopener" class="gold">Open WhatsApp ↗</a>`;
  window.open(url, '_blank', 'noopener'); if (saved) f.reset();
}
wire('buyerEnquiryForm', e => {
  const fd = new FormData(e.target), g = k => String(fd.get(k) || '').trim();
  submitEnquiry(e, 'BUY', { name: g('name'), phone: g('phone'), email: g('email'), locality: g('locality'), budget: g('budget'), bedrooms: g('beds'), area: g('area'), propertyCode: g('propertyId'), details: g('details') },
    `Hello Assam Property Dealer, I want to buy an apartment.\nName: ${g('name')}\nPhone: ${g('phone')}\nEmail: ${g('email') || 'Not provided'}\nLocality: ${g('locality') || 'Any'}\nBudget: ${g('budget')}\nBedrooms: ${g('beds')}\nArea: ${g('area') || 'Not specified'}\nProperty ID: ${g('propertyId') || 'Not specified'}\nRequirements: ${g('details') || 'Not specified'}`);
});
wire('sellForm', e => {
  const fd = new FormData(e.target), g = k => String(fd.get(k) || '').trim();
  const details = `Owner wants to list a flat. Type: ${g('type') || '-'}. Expected price: ${g('price') || '-'}. Area: ${g('area') || '-'} sq ft. ${g('details')}`.slice(0, 1900);
  submitEnquiry(e, 'SELL', { name: g('name'), phone: g('phone'), locality: g('location'), area: g('area'), details },
    `Hello Assam Property Dealer! I would like to list my property.\nName: ${g('name')}\nPhone: ${g('phone')}\nLocation: ${g('location')}\nType: ${g('type')}\nExpected price: ${g('price') || 'Not specified'}\nArea: ${g('area') || 'Not specified'} sq.ft.\nDetails: ${g('details') || 'Not specified'}`);
});
(() => { const w = document.querySelector('#visitForm [name=when]'); if (w) { const n = new Date(); w.min = new Date(n - n.getTimezoneOffset() * 6e4).toISOString().slice(0, 16); } })();
wire('visitForm', async e => {
  e.preventDefault(); const f = e.target, fd = new FormData(f), g = k => String(fd.get(k) || '').trim(), note = noteFor(f), btn = $('visitBtn');
  const when = g('when'), d = new Date(when);
  if (g('name').length < 2 || !validPhone(g('phone'))) { note.textContent = 'Please enter your name and a valid 10-digit mobile number.'; return; }
  if (!when || isNaN(d)) { note.textContent = 'Please choose a date and time.'; return; }
  if (d.getDay() === 4) { note.textContent = 'Our office is closed on Thursdays. Please pick another day.'; return; }
  if (d.getHours() < 10 || d.getHours() >= 17) { note.textContent = 'Visits are available between 10:00 AM and 5:00 PM.'; return; }
  btn.disabled = true;
  try {
    const r = await post('/api/appointments', { name: g('name'), phone: g('phone'), preferredAt: when, propertyCode: g('propertyCode'), location: g('location'), requirements: g('requirements'), website: g('website') });
    const m = `Hello Assam Property Dealer, I requested a site visit on ${d.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}.\nName: ${g('name')}\nProperty ID / area: ${g('propertyCode') || g('location') || 'Not specified'}`;
    note.innerHTML = `Your visit request has been received. APD will confirm the time with you by phone or WhatsApp; it is not confirmed until then. ${esc(r.note || '')} <a class="gold" href="${esc(waLink(m))}" target="_blank" rel="noopener">Message APD on WhatsApp ↗</a>`; f.reset();
  } catch (x) { note.textContent = x.message; }
  btn.disabled = false;
});

/* ---------- startup ---------- */
function banner(t) { const h = document.querySelector('.hero-content'); if (h) h.insertAdjacentHTML('afterbegin', `<div class="ann">${esc(t)}</div>`); }
(async function boot() {
  properties.length = 0; visible = []; $('resultCount').textContent = 'Loading properties…'; renderProperties();
  try {
    const [l, c, ps, s] = await Promise.all([j('/api/localities'), j('/api/categories'), j('/api/properties'), j('/api/settings').catch(() => ({}))]);
    live = true; LOCS = l; properties.push(...ps.map(map)); visible = [...properties];
    fillSelects(c); drawLocalities();
    if (s.announcement) banner(s.announcement);
    if (s.officeAddress) $('officeAddress').textContent = s.officeAddress;
    if (s.officeHours) $('officeHours').textContent = s.officeHours;
  } catch (x) {
    live = false; properties.push(...DEMO); visible = [...properties];
    LOCS = [...new Set(DEMO.map(d => d.location))].map(n => ({ name: n, slug: n, zone: 'Demo localities', availableCount: DEMO.filter(d => d.location === n).length }));
    fillSelects(['Apartment']); drawLocalities();
    banner('Preview mode: the APD server is not connected, so these are illustrative demo listings, not real inventory.');
  }
  renderProperties();
})();
})();
