'use strict';
const $ = (s, e = document) => e.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
class Raw { constructor(s) { this.s = s } }
const raw = s => new Raw(s);
// h`...` escapes every interpolated value unless wrapped in raw() -- prevents stored XSS from customer-entered text
const h = (s, ...v) => s.reduce((a, x, i) => a + x + (i < v.length ? (v[i] instanceof Raw ? v[i].s : esc(v[i])) : ''), '');
let ME = null;
const WA = '91';
const inr = n => '₹' + Number(n || 0).toLocaleString('en-IN');
const dt = d => d ? new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '';
const dOnly = d => d ? new Date(d).toLocaleDateString('en-IN', { dateStyle: 'medium' }) : '';
const loc = d => { if (!d) return ''; const x = new Date(d); return new Date(x - x.getTimezoneOffset() * 6e4).toISOString().slice(0, 16); };
const day = d => d ? new Date(new Date(d) - new Date(d).getTimezoneOffset() * 6e4).toISOString().slice(0, 10) : '';

async function api(u, o = {}) {
  const m = o.method || 'GET', hd = {};
  if (o.body && !(o.body instanceof FormData)) hd['Content-Type'] = 'application/json';
  if (m !== 'GET') hd['X-CSRF-Token'] = ME?.csrf || '';
  const r = await fetch('/api/admin' + u, { method: m, credentials: 'same-origin', headers: hd, body: o.body instanceof FormData ? o.body : o.body && JSON.stringify(o.body) });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && ME) { location.reload(); }
  if (!r.ok) throw Error(d.error || 'Request failed');
  return d;
}
const toast = m => alert(m);

/* ---------- generic form dialog ---------- */
function field(f, v) {
  const n = `name="${f.k}"`, req = f.req ? ' required' : '';
  const val = f.t === 'checkbox' && !v ? f.def : v?.[f.k];
  if (f.t === 'checkbox') return h`<label class="cb"><input type="checkbox" ${raw(n)} ${raw(val ? 'checked' : '')}> ${f.label}</label>`;
  let c;
  if (f.t === 'select') c = h`<select ${raw(n + req)}>${raw(f.opt ? '<option value="">—</option>' : '')}${raw(f.opts().map(([a, b]) => h`<option value="${a}" ${raw(String(val ?? f.def ?? '') === String(a) ? 'selected' : '')}>${b}</option>`).join(''))}</select>`;
  else if (f.t === 'textarea') c = h`<textarea ${raw(n + req)} rows="4">${val ?? ''}</textarea>`;
  else if (f.t === 'media') return h`<label>${f.label}</label><input type="file" id="mfile" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" multiple><div class="thumbs" id="thumbs"></div>`;
  else {
    const type = f.t === 'tags' ? 'text' : f.t === 'datetime' ? 'datetime-local' : f.t || 'text';
    const v2 = f.t === 'tags' ? (val || []).join(', ') : f.t === 'datetime' ? loc(val) : f.t === 'date' ? day(val) : (val ?? f.def ?? '');
    c = h`<input type="${type}" ${raw(n + req)} value="${v2}" ${raw(f.step ? `step="${f.step}"` : '')}>`;
  }
  return h`<label>${f.label}${f.hint ? raw(` <span class="mut">(${esc(f.hint)})</span>`) : ''}</label>${raw(c)}`;
}
function openForm({ title, fields, value, onSave, extra }) {
  const d = $('#dlg');
  let media = (value?.media || []).map(m => ({ url: m.url, kind: m.kind }));
  d.innerHTML = h`<h2>${title}</h2><form id="df"><div class="g2">${raw(fields.map(f => `<div class="${f.wide || f.t === 'textarea' || f.t === 'media' ? '' : ''}" style="${f.wide || ['textarea', 'media'].includes(f.t) ? 'grid-column:1/-1' : ''}">${field(f, value)}</div>`).join(''))}</div><p class="err" id="derr"></p><div class="bar" style="margin-top:12px"><button>Save</button><button type="button" class="alt" id="dx">Cancel</button></div></form>${raw(extra || '')}`;
  const drawThumbs = () => { const t = $('#thumbs'); if (!t) return; t.innerHTML = media.map((m, i) => h`<div>${raw(m.kind === 'VIDEO' ? h`<video src="${m.url}" muted></video>` : h`<img src="${m.url}" alt="">`)}<button type="button" data-rm="${i}" title="Remove">×</button></div>`).join(''); };
  drawThumbs();
  d.onclick = e => { if (e.target.dataset.rm) { media.splice(+e.target.dataset.rm, 1); drawThumbs(); } };
  $('#dx').onclick = () => d.close();
  const mf = $('#mfile');
  if (mf) mf.onchange = async () => { const fd = new FormData(); [...mf.files].forEach(f => fd.append('files', f)); $('#derr').textContent = 'Uploading…'; try { media = media.concat(await api('/uploads', { method: 'POST', body: fd })); $('#derr').textContent = ''; drawThumbs(); } catch (x) { $('#derr').textContent = x.message; } mf.value = ''; };
  $('#df').onsubmit = async e => {
    e.preventDefault(); const fd = new FormData(e.target), out = {};
    for (const f of fields) {
      if (f.t === 'media') { out[f.k] = media; continue; }
      const v = fd.get(f.k);
      out[f.k] = f.t === 'checkbox' ? e.target.elements[f.k].checked : f.t === 'tags' ? (v || '').split(',').map(x => x.trim()).filter(Boolean) : f.t === 'datetime' ? (v ? new Date(v).toISOString() : '') : v;
    }
    try { await onSave(out); d.close(); } catch (x) { $('#derr').textContent = x.message; }
  };
  d.showModal();
}

/* ---------- generic list screen ---------- */
async function listScreen(cfg) {
  const m = $('#main'); let rows = [];
  const can = ME.access[cfg.area] === 'rw';
  const draw = () => {
    $('#tbl').innerHTML = `<table><tr>${cfg.cols.map(c => `<th>${esc(c[0])}</th>`).join('')}<th></th></tr>${rows.map(r => `<tr>${cfg.cols.map(c => `<td>${c[1](r)}</td>`).join('')}<td style="white-space:nowrap">${cfg.rowActions ? cfg.rowActions(r) : ''}${can ? `<button class="alt" data-e="${esc(r.id)}">Edit</button> <button class="del" data-d="${esc(r.id)}">Delete</button>` : ''}</td></tr>`).join('') || '<tr><td class="mut">Nothing here yet.</td></tr>'}</table>`;
  };
  const load = async () => { try { rows = await api(cfg.path + (cfg.query ? cfg.query() : '')); draw(); } catch (x) { $('#tbl').innerHTML = h`<p class="err">${x.message}</p>`; } };
  m.innerHTML = h`<h2>${cfg.title}</h2>${raw(cfg.note ? h`<p class="mut">${cfg.note}</p>` : '')}<div class="bar">${raw(cfg.filters || '')}${raw(can && !cfg.noAdd ? '<button id="add">+ Add</button>' : '')}</div><div class="card tw" id="tbl">Loading…</div>`;
  const save = row => async v => { await api(row ? `${cfg.path}/${row.id}` : cfg.path, { method: row ? (cfg.patch ? 'PATCH' : 'PUT') : 'POST', body: cfg.prep ? cfg.prep(v, row) : v }); load(); };
  const form = row => openForm({ title: (row ? 'Edit ' : 'Add ') + cfg.one, fields: cfg.fields, value: row, onSave: save(row) });
  $('#add') && ($('#add').onclick = () => form(null));
  m.onclick = async e => {
    const t = e.target;
    if (t.dataset.e) form(rows.find(r => r.id === t.dataset.e));
    if (t.dataset.d && confirm('Delete this ' + cfg.one + '? This cannot be undone.')) { try { await api(`${cfg.path}/${t.dataset.d}`, { method: 'DELETE' }); load(); } catch (x) { toast(x.message); } }
    if (cfg.onClick) cfg.onClick(t, rows, load);
  };
  m.querySelectorAll('.bar select,.bar input').forEach(i => i.onchange = load);
  load();
}
const pill = s => h`<span class="pill">${String(s || '').replace(/_/g, ' ')}</span>`;
let LOC = [], CAT = [], STAFF = [], PROPS = [];
const opts = a => () => a.map(x => [x.id ?? x, x.name ?? x]);
const E = ['NEW', 'CONTACTED', 'FOLLOW_UP', 'SITE_VISIT_SCHEDULED', 'CONVERTED', 'CLOSED'], A = ['REQUESTED', 'CONFIRMED', 'RESCHEDULED', 'COMPLETED', 'CANCELLED'];
const sel = (id, list, any = 'All') => `<div><label>${any}</label><select id="${id}"><option value="">All</option>${list.map(x => `<option value="${x}">${x.replace(/_/g, ' ')}</option>`).join('')}</select></div>`;
const ST = ['DRAFT', 'AVAILABLE', 'UNDER_NEGOTIATION', 'BOOKED', 'SOLD'];

const SCREENS = {
  dashboard: { label: 'Dashboard', area: 'reports', run: dashboard },
  properties: { label: 'Properties', area: 'properties', run: async () => { [LOC, CAT] = await Promise.all([api('/localities'), api('/categories')]); return listScreen({
    area: 'properties', title: 'Properties', one: 'property', path: '/properties', note: 'Only flats for sale. Owner name/phone are private and never shown on the public site.',
    filters: '<div><label>Search code / title</label><input id="q" placeholder="APD-001"></div>', query: () => '?q=' + encodeURIComponent($('#q')?.value || ''),
    cols: [['Code', r => esc(r.propertyCode)], ['Title', r => esc(r.title)], ['Locality', r => esc(r.locality?.name)], ['Price', r => inr(r.price)], ['BHK', r => r.bhk], ['Photos/Videos', r => r.media.length], ['Status', r => pill(r.status)], ['Owner (private)', r => esc(r.ownerPhone || '')]],
    fields: [
      { k: 'propertyCode', label: 'Property ID', req: 1 }, { k: 'title', label: 'Title', req: 1 },
      { k: 'localityId', label: 'Locality', t: 'select', opts: opts(LOC), req: 1 }, { k: 'categoryId', label: 'Category', t: 'select', opts: opts(CAT), opt: 1 },
      { k: 'price', label: 'Price (₹)', t: 'number', req: 1 }, { k: 'status', label: 'Status', t: 'select', opts: () => ST.map(s => [s, s.replace(/_/g, ' ')]), def: 'DRAFT' },
      { k: 'bhk', label: 'BHK', t: 'number', req: 1 }, { k: 'bathrooms', label: 'Bathrooms', t: 'number', def: 1 },
      { k: 'carpetAreaSqFt', label: 'Carpet area (sq ft)', t: 'number' }, { k: 'superBuiltUpSqFt', label: 'Super built-up (sq ft)', t: 'number' },
      { k: 'floor', label: 'Floor', t: 'number' }, { k: 'ageYears', label: 'Property age (years)', t: 'number' },
      { k: 'furnishing', label: 'Furnishing', t: 'select', opts: () => [['UNFURNISHED', 'Unfurnished'], ['SEMI_FURNISHED', 'Semi-furnished'], ['FURNISHED', 'Furnished']] }, { k: 'parking', label: 'Parking' },
      { k: 'lift', label: 'Lift available', t: 'checkbox' }, { k: 'featured', label: 'Featured on homepage', t: 'checkbox' },
      { k: 'amenities', label: 'Amenities', t: 'tags', hint: 'comma separated', wide: 1 }, { k: 'description', label: 'Description', t: 'textarea', req: 1 },
      { k: 'media', label: 'Photos & videos (JPG/PNG/WebP/MP4/WebM, max 25 MB each)', t: 'media' },
      { k: 'ownerName', label: 'Owner name (PRIVATE)' }, { k: 'ownerPhone', label: 'Owner phone (PRIVATE)' }] }); } },
  localities: { label: 'Localities', area: 'localities', run: () => listScreen({ area: 'localities', title: 'Localities', one: 'locality', path: '/localities', note: 'Deactivate a locality to hide it from the public site. Zone names group localities on the public directory.',
    cols: [['Name', r => esc(r.name)], ['Zone', r => esc(r.zone)], ['Properties', r => r._count.properties], ['Active', r => r.active ? 'Yes' : 'No']],
    fields: [{ k: 'name', label: 'Locality name', req: 1 }, { k: 'zone', label: 'Zone', req: 1 }, { k: 'active', label: 'Active (visible on site)', t: 'checkbox', def: true }] }) },
  categories: { label: 'Categories', area: 'categories', run: () => listScreen({ area: 'categories', title: 'Property categories', one: 'category', path: '/categories', cols: [['Name', r => esc(r.name)], ['Active', r => r.active ? 'Yes' : 'No']], fields: [{ k: 'name', label: 'Name', req: 1 }, { k: 'active', label: 'Active', t: 'checkbox' }] }) },
  enquiries: { label: 'Enquiries', area: 'enquiries', run: () => enquiries() },
  appointments: { label: 'Visits', area: 'appointments', run: async () => { STAFF = await api('/staff').catch(() => []); return listScreen({
    area: 'appointments', title: 'Site visit appointments', one: 'appointment', path: '/appointments', patch: 1, note: 'Times are shown in your device’s time zone. “WhatsApp” opens a pre-written confirmation message to the customer; you must press Send.',
    filters: sel('st', A, 'Status') + '<div><label>From</label><input type="date" id="f1"></div><div><label>To</label><input type="date" id="f2"></div><div><label>&nbsp;</label><button class="alt" id="td">Today</button> <button class="alt" id="mo">This month</button></div>',
    query: () => `?status=${$('#st')?.value || ''}&from=${$('#f1')?.value || ''}&to=${$('#f2')?.value || ''}`,
    cols: [['When', r => dt(r.preferredAt)], ['Customer', r => `${esc(r.name)}<br><span class="mut">${esc(r.phone)}</span>`], ['Property / area', r => esc(r.propertyCode || r.location || '')], ['Requirements', r => esc(r.requirements || '')], ['Executive', r => esc(r.staff?.name || '—')], ['Status', r => pill(r.status)], ['Visit fee', r => r.feeRequired ? pill(r.feeStatus) : '<span class="mut">first visit free</span>']],
    rowActions: r => `<button class="alt" data-wa="${esc(r.id)}">WhatsApp</button> `, noAdd: 1,
    fields: [{ k: 'status', label: 'Status', t: 'select', opts: () => A.map(s => [s, s]) }, { k: 'preferredAt', label: 'Date & time', t: 'datetime' }, { k: 'staffId', label: 'Assign site executive', t: 'select', opts: opts(STAFF.filter(s => s.active)), opt: 1 }, { k: 'feeStatus', label: 'Visit fee (₹500 refundable)', t: 'select', opts: () => ['NOT_REQUIRED', 'PENDING', 'PAID', 'REFUNDED'].map(s => [s, s.replace('_', ' ')]) }, { k: 'adminNote', label: 'Internal note', t: 'textarea' }],
    prep: v => ({ ...v, preferredAt: v.preferredAt || undefined, staffId: v.staffId || null }),
    onClick: (t, rows) => {
      if (t.id === 'td') { $('#f1').value = $('#f2').value = day(new Date()); $('#f1').onchange(); }
      if (t.id === 'mo') { const n = new Date(); $('#f1').value = day(new Date(n.getFullYear(), n.getMonth(), 1)); $('#f2').value = day(new Date(n.getFullYear(), n.getMonth() + 1, 0)); $('#f1').onchange(); }
      if (t.dataset.wa) { const a = rows.find(r => r.id === t.dataset.wa); const msg = `Hello ${a.name}, this is Assam Property Dealer. Your property visit${a.propertyCode ? ' for ' + a.propertyCode : ''} is ${a.status.toLowerCase()} for ${dt(a.preferredAt)}.${a.staff ? ' Our executive ' + a.staff.name + ' will assist you.' : ''} Office: Eastern Hut, Flat 103, Noonmati Bus Stop, Guwahati. Please reply if you need to change the time.`; open(`https://wa.me/${WA}${a.phone}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener'); }
    } }); } },
  staff: { label: 'Staff', area: 'staff', run: () => listScreen({ area: 'staff', title: 'Site executives & staff', one: 'staff member', path: '/staff', note: 'Staff profiles for visit assignment. This is separate from admin logins (see Users).',
    cols: [['Name', r => esc(r.name)], ['Phone', r => esc(r.phone)], ['Assigned area', r => esc(r.area || '')], ['Responsibilities', r => esc(r.responsibilities || '')], ['Active', r => r.active ? 'Yes' : 'No']],
    fields: [{ k: 'name', label: 'Name', req: 1 }, { k: 'phone', label: 'Phone', req: 1 }, { k: 'area', label: 'Assigned area / localities' }, { k: 'responsibilities', label: 'Responsibilities', t: 'textarea' }, { k: 'active', label: 'Active', t: 'checkbox', def: true }] }) },
  sales: { label: 'Sales & brokerage', area: 'sales', run: async () => { PROPS = await api('/properties'); return listScreen({ area: 'sales', title: 'Sales & brokerage (private)', one: 'sale', path: '/sales', note: 'Default brokerage is 2% of the final transaction price. Visible only to roles with accounts access.',
    cols: [['Date', r => dOnly(r.saleDate)], ['Property', r => esc(r.property?.propertyCode + ' · ' + r.property?.title)], ['Buyer', r => esc(r.buyerName)], ['Final price', r => inr(r.finalPrice)], ['Brokerage', r => `${inr(r.brokerageAmount)} <span class="mut">(${Number(r.brokeragePct)}%)</span>`], ['Brokerage status', r => pill(r.brokerageStatus)]],
    fields: [{ k: 'propertyId', label: 'Property', t: 'select', opts: () => PROPS.map(p => [p.id, p.propertyCode + ' · ' + p.title]), req: 1 }, { k: 'buyerName', label: 'Buyer name', req: 1 }, { k: 'buyerPhone', label: 'Buyer phone' }, { k: 'finalPrice', label: 'Final transaction price (₹)', t: 'number', req: 1 }, { k: 'brokeragePct', label: 'Brokerage %', t: 'number', step: '0.01', def: 2 }, { k: 'brokerageStatus', label: 'Brokerage status', t: 'select', opts: () => [['PENDING', 'Pending'], ['RECEIVED', 'Received']] }, { k: 'saleDate', label: 'Sale date', t: 'date', req: 1, def: day(new Date()) }, { k: 'notes', label: 'Notes', t: 'textarea' }, { k: 'markSold', label: 'Mark property as SOLD', t: 'checkbox', def: true }] }); } },
  users: { label: 'Users', area: 'users', run: () => listScreen({ area: 'users', title: 'Admin logins & roles', one: 'user', path: '/users', note: 'SUPER_ADMIN: everything · ADMIN: properties, enquiries, visits, staff, reports · ACCOUNTS: sales & brokerage, reports · EXECUTIVE: view visits/enquiries only. Passwords need 14+ characters; leave blank on edit to keep the current one.',
    cols: [['Username', r => esc(r.username)], ['Role', r => pill(r.role)], ['Active', r => r.active ? 'Yes' : 'No']],
    fields: [{ k: 'username', label: 'Username', req: 0 }, { k: 'role', label: 'Role', t: 'select', opts: () => ['SUPER_ADMIN', 'ADMIN', 'ACCOUNTS', 'EXECUTIVE'].map(x => [x, x]) }, { k: 'password', label: 'Password', t: 'password' }, { k: 'active', label: 'Active', t: 'checkbox', def: true }],
    prep: (v, row) => row ? { role: v.role, active: v.active, password: v.password } : { username: v.username, role: v.role, password: v.password } }) },
  settings: { label: 'Site settings', area: 'settings', run: settings }
};

async function enquiries() {
  const m = $('#main');
  m.innerHTML = `<h2>Customer enquiries</h2><div class="bar">${sel('st', E, 'Status')}<div><label>Type</label><select id="kd"><option value="">All</option><option value="BUY">Buyer</option><option value="SELL">Owner (selling)</option></select></div><div><label>Search name / phone / property / locality</label><input id="q"></div><div><label>&nbsp;</label><button class="alt" id="due">Follow-ups due</button></div></div><div class="card tw" id="tbl">Loading…</div>`;
  let due = '', rows = [];
  const load = async () => { try { rows = await api(`/enquiries?status=${$('#st').value}&kind=${$('#kd').value}&q=${encodeURIComponent($('#q').value)}${due}`); $('#tbl').innerHTML = `<table><tr><th>Received</th><th>Customer</th><th>Looking for</th><th>Status</th><th>Follow-up</th><th></th></tr>${rows.map(r => `<tr><td>${dt(r.createdAt)}</td><td>${esc(r.name)}<br><span class="mut">${esc(r.phone)}${r.kind === 'SELL' ? ' · owner' : ''}</span></td><td>${esc([r.locality, r.budget, r.bedrooms, r.propertyCode].filter(Boolean).join(' · '))}</td><td>${pill(r.status)}</td><td>${dOnly(r.followUpDate)}</td><td><button class="alt" data-o="${esc(r.id)}">Open</button></td></tr>`).join('') || '<tr><td class="mut">No enquiries found.</td></tr>'}</table>`; } catch (x) { $('#tbl').innerHTML = h`<p class="err">${x.message}</p>`; } };
  ['st', 'kd', 'q'].forEach(i => $('#' + i).onchange = load);
  m.onclick = async e => {
    if (e.target.id === 'due') { due = due ? '' : '&due=1'; load(); }
    if (e.target.dataset.o) {
      const x = await api('/enquiries/' + e.target.dataset.o), can = ME.access.enquiries === 'rw', d = $('#dlg');
      d.innerHTML = h`<h2>${x.name}</h2><p>${x.phone} ${x.email ? '· ' + x.email : ''}<br><span class="mut">${x.kind === 'SELL' ? 'Owner wants to sell · ' : ''}${x.locality || 'Any locality'} · Budget ${x.budget || '—'} · ${x.bedrooms || 'Any'} bedrooms · ${x.area || 'no size given'} · Property ${x.propertyCode || '—'}</span></p><p>${x.details || ''}</p>
      ${raw(can ? h`<div class="g2"><div><label>Status</label><select id="es">${raw(E.map(s => `<option ${s === x.status ? 'selected' : ''} value="${s}">${s.replace(/_/g, ' ')}</option>`).join(''))}</select></div><div><label>Follow-up date</label><input type="date" id="ef" value="${day(x.followUpDate)}"></div></div><div class="bar" style="margin-top:10px"><button id="es2">Save status</button> <a class="btn alt" style="background:none;border:1px solid var(--gold);color:var(--gold)" target="_blank" rel="noopener" href="tel:${x.phone}">Call</a> <a class="btn alt" style="background:none;border:1px solid var(--gold);color:var(--gold)" target="_blank" rel="noopener" href="https://wa.me/${WA}${x.phone}">WhatsApp</a></div><label>Add internal note</label><textarea id="nt" rows="2"></textarea><button id="nb" style="margin-top:6px">Add note</button>` : '')}
      <h3>Notes</h3>${raw(x.notes.map(n => h`<p><b>${n.authorName}</b> <span class="mut">${dt(n.createdAt)}</span><br>${n.text}</p>`).join('') || '<p class="mut">No notes yet.</p>')}
      <h3>History for this phone number</h3>${raw(x.history.map(o => h`<p>${dt(o.createdAt)} · ${o.status.replace(/_/g, ' ')} · ${o.locality || ''} ${o.propertyCode || ''}</p>`).join('') + x.appointments.map(a => h`<p>Visit ${dt(a.preferredAt)} · ${a.status}</p>`).join('') || '<p class="mut">No other activity.</p>')}
      <div class="bar" style="margin-top:12px"><button class="alt" id="xc">Close</button>${raw(can ? '<button class="del" id="xd">Delete enquiry</button>' : '')}</div>`;
      d.showModal(); $('#xc').onclick = () => d.close();
      if (can) {
        $('#es2').onclick = async () => { try { await api('/enquiries/' + x.id, { method: 'PATCH', body: { status: $('#es').value, followUpDate: $('#ef').value ? new Date($('#ef').value).toISOString() : '' } }); d.close(); load(); } catch (z) { toast(z.message); } };
        $('#nb').onclick = async () => { if (!$('#nt').value.trim()) return; try { await api(`/enquiries/${x.id}/notes`, { method: 'POST', body: { text: $('#nt').value } }); d.close(); load(); } catch (z) { toast(z.message); } };
        $('#xd').onclick = async () => { if (confirm('Delete this enquiry permanently?')) { await api('/enquiries/' + x.id, { method: 'DELETE' }); d.close(); load(); } };
      }
    }
  };
  load();
}

async function dashboard() {
  const m = $('#main'), y = new Date().getFullYear();
  const r = await api('/reports?year=' + y), sum = o => Object.values(o || {}).reduce((a, b) => a + b, 0);
  const card = (l, v) => h`<div class="stat"><b>${v}</b>${l}</div>`;
  const mn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const mrow = (a, k = 'c') => Object.fromEntries((a || []).map(x => [x.m, x]));
  const me = mrow(r.monthly.enquiries), ma = mrow(r.monthly.appointments), ms = mrow(r.monthly.sales);
  m.innerHTML = h`<h2>Business overview (${y})</h2><div class="stats">${raw([
    card('Total properties', sum(r.properties)), card('Available', r.properties.AVAILABLE || 0), card('Under negotiation', r.properties.UNDER_NEGOTIATION || 0), card('Booked', r.properties.BOOKED || 0), card('Sold', r.properties.SOLD || 0),
    card('Customer enquiries', sum(r.enquiries)), card('New enquiries', r.enquiries.NEW || 0), card('Property visits (all)', sum(r.appointments)), card('Confirmed visits', r.appointments.CONFIRMED || 0), card('Completed visits', r.appointments.COMPLETED || 0)].join(''))}</div>
  ${raw(r.sales ? h`<h2 style="margin-top:20px">Sales & brokerage (${y}) <span class="mut" style="font-size:13px">private</span></h2><div class="stats">${raw([card('Sales recorded', r.sales.count), card('Sales value', inr(r.sales.value)), card('Brokerage earned', inr(r.sales.brokerage)), card('Brokerage received', inr(r.sales.brokerageReceived))].join(''))}</div>` : '')}
  <h2 style="margin-top:20px">Monthly report ${y}</h2><div class="card tw"><table><tr><th>Month</th><th>Enquiries</th><th>Visits</th>${raw(r.sales ? '<th>Sales</th><th>Sales value</th><th>Brokerage</th>' : '')}</tr>${raw(mn.map((n, i) => { const k = String(i + 1).padStart(2, '0'); return h`<tr><td>${n}</td><td>${me[k]?.c || 0}</td><td>${ma[k]?.c || 0}</td>${raw(r.sales ? h`<td>${ms[k]?.c || 0}</td><td>${inr(ms[k]?.value)}</td><td>${inr(ms[k]?.brokerage)}</td>` : '')}</tr>`; }).join(''))}</table></div>
  <h2 style="margin-top:20px">Staff performance</h2><div class="card tw"><table><tr><th>Executive</th><th>Visits assigned</th><th>Completed</th></tr>${raw(r.staff.map(s => h`<tr><td>${s.name}</td><td>${s.assigned}</td><td>${s.completed}</td></tr>`).join('') || '<tr><td class="mut">No staff added yet.</td></tr>')}</table></div>`;
}
async function settings() {
  const s = await api('/settings'), can = ME.access.settings === 'rw';
  $('#main').innerHTML = h`<h2>Site settings</h2><div class="card"><form id="sf"><label>Announcement banner (leave empty for none)</label><input name="announcement" value="${s.announcement || ''}"><label>Office address</label><input name="officeAddress" value="${s.officeAddress || ''}"><label>Office hours</label><input name="officeHours" value="${s.officeHours || ''}">${raw(can ? '<p><button>Save settings</button></p>' : '')}</form></div>`;
  $('#sf').onsubmit = async e => { e.preventDefault(); try { await api('/settings', { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) }); toast('Saved'); } catch (x) { toast(x.message); } };
}

function start() {
  $('#login').hidden = true; $('#app').hidden = false; $('#who').textContent = `${ME.username} · ${ME.role.replace('_', ' ')}`;
  const tabs = Object.entries(SCREENS).filter(([, v]) => ME.access[v.area]);
  $('#nav').innerHTML = tabs.map(([k, v]) => `<button data-t="${k}">${v.label}</button>`).join('');
  const go = async k => { $('#nav').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.t === k)); $('#main').innerHTML = 'Loading…'; try { await SCREENS[k].run(); } catch (x) { $('#main').innerHTML = h`<p class="err">${x.message}</p>`; } };
  $('#nav').onclick = e => e.target.dataset.t && go(e.target.dataset.t);
  go(tabs[0][0]);
}
$('#lf').onsubmit = async e => { e.preventDefault(); const f = new FormData(e.target); try { ME = await api('/login', { method: 'POST', body: { username: f.get('u'), password: f.get('p') } }); start(); } catch (x) { $('#lmsg').textContent = x.message; } };
$('#out').onclick = async () => { try { await api('/logout', { method: 'POST' }); } finally { location.reload(); } };
api('/me').then(m => { ME = m; start(); }).catch(() => {});
